<?php

$config = array(
    'Settings' => array(
        'WEBSITE' => 'http://okuntakinte.fifthlightmedia.com/',
        'SHOP_TITLE' => 'Okuntakinte Shopping Cart',
        'ADMIN_EMAIL' => 'jnartey@gmail.com',
        'DOMAIN' => '',
        'ANALYTICS' => '',
        'PAYPAL_API_USERNAME' => 'jawuahdarko@yahoo.com',
        'PAYPAL_API_PASSWORD' => 'fifthlight00!',
        'PAYPAL_API_SIGNATURE' => '',
        'AUTHORIZENET_ENABLED' => '1',
        'AUTHORIZENET_API_URL' => 'https://test.authorize.net/gateway/transact.dll',
        'AUTHORIZENET_API_LOGIN' => '',
        'AUTHORIZENET_API_TRANSACTION_KEY' => '',
    )
);


