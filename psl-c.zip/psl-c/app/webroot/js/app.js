jQuery("#layerslider").layerSlider({
	responsive: false,
	responsiveUnder: 1280,
	layersContainer: 1280,
	skin: 'noskin',
	hoverPrevNext: true,
	pauseOnHover: false,
	skinsPath: 'layerslider/skins/'
});

$(document).ready(function() {
    $('.industries').portfolio({
        cols: 4,
        transition: 'slideDown'
    });
});

// (function($) {
//
// 	var head = $('.head'),
// 		menu = $('.menu-wrapper'),
// 		banner = $('.banner'),
// 		aboutUs = $('#about-us'),
// 		services = $('#services'),
// 		verticalIndustries = $('#vertical-industries'),
// 		globalNetwork = $('#global-network'),
// 		contactUs = $('#contact-us'),
// 		footer = $('.footer'),
// 		links = $('.links li'),
// 		tlHead = new TimelineMax();
//
// 		// Staggering Animations
// 		// tl
// // 		.fromTo(head, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut})
// // 		.fromTo(menu, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(banner, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(aboutUs, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(services, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(verticalIndustries, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(globalNetwork, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(contactUs, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.fromTo(footer, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
// // 		.staggerFrom(links, 1, {cycle: {
// // 			x: [50],
// // 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.5);
//
//
// })(jQuery);


(function($) {
	
	$('a.link-push').on('click', function(){
		var target = $(this).attr('href');
		target = $(target).offset().top;
		TweenMax.to($(window), 1, {scrollTo:{y:target, autoKill: true}, ease:Power3.easeOut});
		return false;
	});
	
	// $('#industries-tabs.tabs .tabs-title').on('click', function(){
// 		var target = $('#industries-content');
// 		target = $(target).offset().top;
// 		TweenMax.to($(window), 1, {scrollTo:{y:target, autoKill: true}, ease:Power3.easeOut});
// 		return false;
// 	});
	
	// $('#services-tabs.tabs .tabs-title').click(function() {
// 		var line = $(this).find(".v-line");
// 		TweenMax.to(this, .35, {border: "1px solid #ffffff", borderRadius:"50%", ease:Power1.easeOut});
// 		TweenMax.to(line, 1, {y: 20, autoAlpha: 1, ease:Power1.easeOut});
// 	});
	
	// $('#services-tabs.tabs .tabs-title a').hover(function() {
// 		var line = $(this).find(".v-line");
// 	  	TweenMax.to(this, .45, {autoAlpha: 1, border: "1px solid #ffffff", borderRadius:"50%", ease:Power1.easeOut});
// 		TweenMax.fromTo(line, 1, {y: 20, autoAlpha: 1, ease:Power1.easeOut}, {y: 0, autoAlpha: 1, ease:Power1.easeOut});
// 	}, function() {
// 		var line = $(this).find(".v-line");
// 		TweenMax.to(this, .5, {border: "1px solid transparent", borderRadius:"0", ease:Power1.easeOut});
// 		TweenMax.fromTo(line, 1, {y: 0, autoAlpha: 1, ease:Power1.easeOut}, {y: 20, autoAlpha: 0, ease:Power1.easeOut});
// 	});
	
	// $('#services-tabs.tabs .tabs-title.is-active a').hover(function() {
// 		var line = $(this).find(".v-line");
// 		TweenMax.to(this, .35, {border: "1px solid #ffffff", borderRadius:"50%", ease:Power1.easeOut});
// 		TweenMax.fromTo(line, 1, {y: 20, autoAlpha: 1, ease:Power1.easeOut}, {y: 0, autoAlpha: 1, ease:Power1.easeOut});
// 	}, function() {
// 		var line = $(this).find(".v-line");
// 		TweenMax.to(this, .5, {border: "1px solid #ffffff", borderRadius:"50%", autoAlpha: 1, ease:Power1.easeOut});
// 		TweenMax.fromTo(line, 1, {y: 20, autoAlpha: 1, ease:Power1.easeOut}, {y: 0, autoAlpha: 1, ease:Power1.easeOut});
// 	})
	
	//Head & menu scroll animation
	var head = $('.head'),
		headContact = $('.head-contact'),
		socialMedia = $('.social-media'),
		socialMediaLinks = $('.social-media a'),
		menu = $('.menu-wrapper'),
		logo = $('.logo'),
		menuLinks = $('.menu li'),
		tlHead = new TimelineMax({});

	var head_tween = tlHead
			.fromTo(head, 0.3, {y: -10, autoAlpha: 1}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}).add('intro')
			.fromTo(headContact, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
			.fromTo(socialMedia, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
			.staggerFrom(socialMediaLinks, 1, {cycle: {
				x: 2, y: 2,
			}, autoAlpha: 0, ease:Quad.easeInOut}, 0.2)
			.fromTo(menu, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power1.easeOut}, 'intro')
			.fromTo(logo, 0.3, {autoAlpha: 0, scale: 1.3}, {autoAlpha: 1, scale: 1, ease:Power0.easeNone}, 'intro')
			.staggerFrom(menuLinks, 0.5, {cycle: {
				x: [15],
			}, autoAlpha: 0, ease:Power1.easeOut}, 0.2, 'intro');

	//banner scroll animation
	var banner = $('#banner'),
		bannerReadMoreLink = $('.link-wrap a'),
		bannerReadMore = $('.link-wrap a img'),
		tlBanner = new TimelineMax({});

	var banner_tween = tlBanner
			.fromTo(banner, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.15')
			.fromTo(bannerReadMoreLink, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.15')
			.fromTo(bannerReadMore, 2, {y: -5, autoAlpha: 1}, {y: 8, autoAlpha: 1, ease:Bounce.easeOut, repeat: -1}, '+=0.15');
		
	//Home page About Us animation
	var hAboutUs = $('#about-us'),
		line = $('#about-us .line'),
		h6 = $('#about-us h6'),
		h5 = $('#about-us h5'),
		p = $('#about-us p'),
		h4 = $('#about-us h4'),
		links = $('#about-us .links li'),
		tlAboutUs = new TimelineMax({});

	var h_about_tween = tlAboutUs
		.fromTo(hAboutUs, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.fromTo(line, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.fromTo(h6, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.fromTo(h5, 0.3, {x: 10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.fromTo(p, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.fromTo(h4, 0.3, {x: 10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.staggerFrom(links, 1, {cycle: {
		 			y: [-35],
		 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.2);
			
	//Home page Services animation
	var hServices = $('#services'),
		line = $('#services .line'),
		h6 = $('#services h6'),
		services = $('#services .services li'),
		servicesTabs = $('#services-tabs li'),
		tlServices = new TimelineMax({});

	var h_services_tween = tlServices
		.fromTo(hServices, 0, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25').add('intro')
		.fromTo(line, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(h6, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.staggerFrom(services, 1, {cycle: {
		 			x: [200],
		 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.2)
		.staggerFrom(servicesTabs, 1, {cycle: {
		 			x: [200],
		 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.2, 'intro');
				
	//Home page Vertical Industries animation
	var hVT = $('#vertical-industries'),
		VTtitle = $('.caption-title'),
		VTslide = $('.caption'),
		VIM = $('#industries-tabs li'),
		VIC = $('.industries-content'),
		tlVT = new TimelineMax({});

	var h_vt_tween = tlVT
		.fromTo(hVT, 0, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=1').add('intro')
		.fromTo(VTtitle, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=1')
		.fromTo(VTslide, 0.3, {x: 10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=1')
		.staggerFrom(VIM, 1, {cycle: {
			x: 2, y: 2,
		}, autoAlpha: 0, ease:Quad.easeInOut}, 0.2, 'intro')
		.fromTo(VIM, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, 'intro+2');
		
	//Home page Global Network animation
	var hGN = $('#global-network'),
		GNh4 = $('#global-network h4'),
		GNp = $('#global-network p'),
		networks = $('#global-network .networks li')
		tlGN = new TimelineMax({});

	var h_gn_tween = tlGN
		.fromTo(hGN, 0, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(GNh4, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(GNp, 0.3, {x: 10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.staggerFrom(networks, 1, {cycle: {
		 			x: [50],
		 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.4);

	//Contact us footer animation
	var fContact = $('#contact-us'),
		buttonLink = $('#contact-us .button-link'),
		fContactp = $('#contact-us p'),
		tlfContact = new TimelineMax({});

	var f_contact_tween = tlfContact
		.fromTo(fContact, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(buttonLink, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(fContactp, 0.3, {x: 10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25');

	//footer animation
	var footer = $('.footer'),
		tlfooter = new TimelineMax({});

	var footer_tween = tlfooter
		.fromTo(footer, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25');
		

	//about us animation
	var board = $('.board'),
		boardHead = $('#board .content-gray'),
		boardTitle = $('.board .title'),
		boardList = $('.board .list .item'),
		boardBase = $('#board .content-blue.misc'),
		missionVisionTitle = $('.content.misc h3'),
		missionVision = $('#mission-vision .title-text-h'),
		tlAbout = new TimelineMax({}),
		tlAbout1 = new TimelineMax({});

	var about_tween = tlAbout
		.fromTo(missionVisionTitle, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.staggerFrom(missionVision, 0.3, {cycle: {
 			x: [50, -50],
 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.4);
		
	var about_tween_1 = tlAbout1
		.fromTo(boardHead, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(board, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.fromTo(boardTitle, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
		.staggerFrom(boardList, 1, {cycle: {
			x: 2, y: 2,
		}, autoAlpha: 0, ease:Quad.easeInOut}, 0.2)
		.fromTo(boardBase, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25');
	
	// init ScrollMagic Controller
	var controller = new ScrollMagic.Controller({
					globalSceneOptions: {
						triggerHook: "onEnter"
					}
				});
	
	// Scale Scene
	var head_scene = new ScrollMagic.Scene({
		
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(head[0])
	.setTween(head_tween);

	var banner_scene = new ScrollMagic.Scene({
	  
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(banner[0])
	.setTween(banner_tween);

	var h_about_scene = new ScrollMagic.Scene({
	  	
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(hAboutUs[0])
	.setTween(h_about_tween);

	var h_services_scene = new ScrollMagic.Scene({
	  	reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(hServices[0])
	.setTween(h_services_tween);
	
	var h_vt_scene = new ScrollMagic.Scene({
	  	reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(hVT[0])
	.setTween(h_vt_tween);
	
	var h_gn_scene = new ScrollMagic.Scene({
	  	reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(hGN[0])
	.setTween(h_gn_tween);
	
	var h_contact_scene = new ScrollMagic.Scene({
	  	reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(fContact[0])
	.setTween(f_contact_tween);
	
	var footer_scene = new ScrollMagic.Scene({
	  	reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement(footer[0])
	.setTween(footer_tween);
	
	var about_scene = new ScrollMagic.Scene({
	  	offset: 50,
		reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement('#mission-vision')
	.setTween(about_tween);
	
	var about_scene_1 = new ScrollMagic.Scene({
		reverse:false
	})
	.addTo(controller)
	.triggerHook("onEnter")
	.triggerElement('#board')
	.setTween(about_tween_1);
	
}(jQuery));

$(document).foundation()
